These three scripts (`compare_eval.py`, `compare_eval_v2_final.py`,
`recompute_metrics.py`) are kept here only for provenance — Reviewer 3
(Round 2) correctly identified that they implemented inconsistent
combinations of two fixes:

  - `compare_eval_v2.py` (pre-fix) had the full-denominator aggregation
    fix (zero_fill_skipped) but NOT the ROUGE tokenizer fix.
  - `compare_eval_v2_final.py` had the ROUGE tokenizer fix but NOT the
    aggregation fix (its `_agg()` still filtered skipped rows out before
    averaging).
  - `recompute_metrics.py` applied yet another combination of metric
    implementations and preprocessing.

There was no way for a reader to tell which one produced the manuscript's
tables. `evaluation/compare_eval_v2.py` now has BOTH fixes applied and is
the single canonical evaluation script going forward. Do not run the
scripts in this folder to generate reported results.

`restore_recall_at_k.py` is also deprecated: it restored values for the
old, now-renamed lexical "recall_at_k" proxy from an earlier run. That
metric is now computed under the name `ref_token_coverage` by
`evaluation/compare_eval_v2.py` directly (no restore step needed), and
real gold-evidence retrieval metrics (Hit@k/MRR/nDCG) are computed
separately by `evaluation/retrieval_eval.py`.
