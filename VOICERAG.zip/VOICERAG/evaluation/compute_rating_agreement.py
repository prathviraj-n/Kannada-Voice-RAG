"""
evaluation/compute_rating_agreement.py

Merges two annotators' completed rating sheets (from
build_human_rating_sheet.py), computes inter-rater agreement (Cohen's
kappa for the categorical faithfulness field, and a simple exact-match
rate for the numeric scales), and summarizes RAG vs No-RAG faithfulness
using the hidden _true_system column.

USAGE:
  python evaluation/compute_rating_agreement.py \
      --annotator1 rater1_filled.csv \
      --annotator2 rater2_filled.csv
"""
import csv, argparse
from collections import Counter

def load(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))

def cohens_kappa(labels1, labels2):
    assert len(labels1) == len(labels2)
    n = len(labels1)
    if n == 0:
        return 0.0
    observed_agreement = sum(1 for a, b in zip(labels1, labels2) if a == b) / n

    categories = set(labels1) | set(labels2)
    p1 = Counter(labels1)
    p2 = Counter(labels2)
    expected_agreement = sum((p1[c] / n) * (p2[c] / n) for c in categories)

    if expected_agreement == 1.0:
        return 1.0
    return (observed_agreement - expected_agreement) / (1 - expected_agreement)


def run(path1, path2):
    rows1, rows2 = load(path1), load(path2)
    assert len(rows1) == len(rows2), "Annotators rated a different number of rows — check both files match the same sheet."

    # Faithfulness categorical agreement
    faith1 = [r["faithfulness"].strip().lower() for r in rows1]
    faith2 = [r["faithfulness"].strip().lower() for r in rows2]
    kappa = cohens_kappa(faith1, faith2)
    print(f"Cohen's kappa (faithfulness category): {kappa:.3f}")
    print("  Interpretation: <0.20 slight, 0.21-0.40 fair, 0.41-0.60 moderate, "
          "0.61-0.80 substantial, 0.81-1.00 almost perfect (Landis & Koch, 1977)")

    # Numeric scale agreement (exact match rate + mean absolute difference)
    for field in ["answer_correctness_1to5", "kannada_fluency_1to5", "context_relevance_1to5"]:
        vals1, vals2, diffs = [], [], []
        for r1, r2 in zip(rows1, rows2):
            v1, v2 = r1.get(field, "").strip(), r2.get(field, "").strip()
            if v1 and v2:
                try:
                    diffs.append(abs(int(v1) - int(v2)))
                except ValueError:
                    continue
        if diffs:
            exact = sum(1 for d in diffs if d == 0) / len(diffs)
            print(f"{field}: exact-match rate={exact:.2%}, mean abs diff={sum(diffs)/len(diffs):.2f} (n={len(diffs)})")

    # RAG vs No-RAG faithfulness breakdown (using rater 1's labels + hidden true system)
    print(f"\n{'='*60}\nFaithfulness by system (rater 1)\n{'='*60}")
    by_system = {"RAG": Counter(), "NoRAG": Counter()}
    for r in rows1:
        sysname = r.get("_true_system_DO_NOT_SHOW_ANNOTATOR", "").strip()
        faith = r.get("faithfulness", "").strip().lower()
        if sysname in by_system and faith:
            by_system[sysname][faith] += 1
    for sysname, counts in by_system.items():
        total = sum(counts.values())
        print(f"  {sysname} (n={total}):")
        for cat, cnt in counts.most_common():
            print(f"    {cat}: {cnt} ({cnt/total:.1%})")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--annotator1", required=True)
    p.add_argument("--annotator2", required=True)
    args = p.parse_args()
    run(args.annotator1, args.annotator2)
