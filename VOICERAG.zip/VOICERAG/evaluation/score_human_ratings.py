"""
evaluation/score_human_ratings.py

Scores the two returned rater workbooks from build_human_rating_v2.py.

Reports
  - completeness check (blank / invalid cells)
  - inter-rater agreement: Cohen's kappa (faithfulness, 4 categories and
    supported-vs-not), quadratic-weighted kappa and exact agreement for the
    1-5 scales
  - per-system results (RAG vs No-RAG), unblinded via the answer key:
      fully-supported rate, supported-or-partial rate, mean correctness, mean fluency
    each with a 95% bootstrap CI over QUESTIONS (both raters averaged per
    question, so the unit of analysis is the question, not the rating)
  - paired RAG minus No-RAG difference per question, bootstrap CI and a
    paired sign-flip permutation p-value
  - a release file (ratings_release.csv) with rater ids anonymised as R1/R2
    and notes REMOVED (review notes before sharing them separately).

USAGE:
  python evaluation/score_human_ratings.py --rater1 rater1.xlsx --rater2 rater2.xlsx \
      --key human_study/ANSWER_KEY_DO_NOT_SHARE.json --out_dir human_study/results
"""
import os, csv, json, argparse, random
from collections import Counter

FAITH = ["supported", "partially_supported", "contradicted", "unsupported"]


def load(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True)["Ratings"]
    hdr = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    return [dict(zip(hdr, [c.value for c in row])) for row in ws.iter_rows(min_row=2) if row[0].value]


def kappa(a, b, cats):
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum((ca[c] / n) * (cb[c] / n) for c in cats)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def qw_kappa(a, b, lo=1, hi=5):
    k = hi - lo + 1; n = len(a)
    O = [[0] * k for _ in range(k)]
    for x, y in zip(a, b): O[x - lo][y - lo] += 1
    ra = [sum(O[i]) for i in range(k)]; cb = [sum(O[i][j] for i in range(k)) for j in range(k)]
    num = den = 0.0
    for i in range(k):
        for j in range(k):
            w = ((i - j) ** 2) / ((k - 1) ** 2)
            num += w * O[i][j]; den += w * ra[i] * cb[j] / n
    return 1.0 if den == 0 else 1 - num / den


def boot_ci(v, n=10000, seed=1):
    rng = random.Random(seed); m = len(v)
    means = sorted(sum(v[rng.randrange(m)] for _ in range(m)) / m for _ in range(n))
    return round(means[int(.025 * n)], 3), round(means[int(.975 * n)], 3)


def signflip_p(d, n=20000, seed=2):
    rng = random.Random(seed); obs = abs(sum(d) / len(d)); c = 0
    for _ in range(n):
        if abs(sum(x if rng.random() < .5 else -x for x in d) / len(d)) >= obs - 1e-12: c += 1
    return round((c + 1) / (n + 1), 5)


def run(a):
    key = {(k["question_id"], k["system_id"]): k["true_system"] for k in json.load(open(a.key, encoding="utf-8"))}
    R = [load(a.rater1), load(a.rater2)]
    assert len(R[0]) == len(R[1]) == len(key), f"row counts differ: {len(R[0])}, {len(R[1])}, key {len(key)}"
    problems = []
    for ri, rows in enumerate(R, 1):
        for i, r in enumerate(rows):
            if (r["question_id"], r["system_id"]) not in key: problems.append(f"R{ri} row {i+2}: unknown id")
            f = (r.get("faithfulness") or "").strip().lower(); r["faithfulness"] = f
            if f not in FAITH: problems.append(f"R{ri} row {i+2}: faithfulness '{f}'")
            for c in ("answer_correctness_1to5", "kannada_fluency_1to5"):
                v = r.get(c)
                if not isinstance(v, (int, float)) or not 1 <= v <= 5: problems.append(f"R{ri} row {i+2}: {c} '{v}'")
    if problems:
        print(f"INCOMPLETE/INVALID: {len(problems)} problems, e.g.:"); [print("  ", p) for p in problems[:15]]
        raise SystemExit("Fix the workbooks (or ask the rater to) and rerun.")
    for ri in (0, 1): R[ri] = {(r["question_id"], r["system_id"]): r for r in R[ri]}
    ids = sorted(key)
    out = {"n_rows": len(ids)}

    f1 = [R[0][k]["faithfulness"] for k in ids]; f2 = [R[1][k]["faithfulness"] for k in ids]
    out["agreement"] = {
        "faithfulness_kappa_4cat": round(kappa(f1, f2, FAITH), 3),
        "faithfulness_kappa_supported_vs_not": round(kappa([x == "supported" for x in f1], [x == "supported" for x in f2], [True, False]), 3),
        "faithfulness_exact": round(sum(x == y for x, y in zip(f1, f2)) / len(ids), 3)}
    for c in ("answer_correctness_1to5", "kannada_fluency_1to5"):
        x = [int(R[0][k][c]) for k in ids]; y = [int(R[1][k][c]) for k in ids]
        out["agreement"][c] = {"quadratic_kappa": round(qw_kappa(x, y), 3),
                               "exact": round(sum(p == q for p, q in zip(x, y)) / len(ids), 3),
                               "within_1": round(sum(abs(p - q) <= 1 for p, q in zip(x, y)) / len(ids), 3)}
    print("INTER-RATER AGREEMENT"); print(json.dumps(out["agreement"], indent=2))

    def score(r, metric):
        if metric == "supported": return float(r["faithfulness"] == "supported")
        if metric == "supported_or_partial": return float(r["faithfulness"] in ("supported", "partially_supported"))
        return float(r[metric])
    metrics = ["supported", "supported_or_partial", "answer_correctness_1to5", "kannada_fluency_1to5"]
    qids = sorted({k[0] for k in ids})
    per = {m: {"RAG": {}, "NoRAG": {}} for m in metrics}
    for (q, s) in ids:
        sysn = key[(q, s)]
        for m in metrics: per[m][sysn][q] = (score(R[0][(q, s)], m) + score(R[1][(q, s)], m)) / 2
    out["systems"], out["paired_rag_minus_norag"] = {}, {}
    print(f"\nRAG vs No-RAG over {len(qids)} questions (unit = question, mean of two raters)")
    for m in metrics:
        row = {}
        for sysn in ("RAG", "NoRAG"):
            v = [per[m][sysn][q] for q in qids]
            row[sysn] = {"mean": round(sum(v) / len(v), 3), "ci95": boot_ci(v)}
        d = [per[m]["RAG"][q] - per[m]["NoRAG"][q] for q in qids]
        out["systems"][m] = row
        out["paired_rag_minus_norag"][m] = {"mean_diff": round(sum(d) / len(d), 3), "ci95": boot_ci(d),
                                            "p_signflip": signflip_p(d), "n_questions": len(d)}
        print(f"  {m:<26} RAG {row['RAG']['mean']:.3f} {row['RAG']['ci95']}  NoRAG {row['NoRAG']['mean']:.3f} {row['NoRAG']['ci95']}"
              f"  diff {out['paired_rag_minus_norag'][m]['mean_diff']:+.3f} {out['paired_rag_minus_norag'][m]['ci95']} p={out['paired_rag_minus_norag'][m]['p_signflip']}")
    dist = {s: Counter() for s in ("RAG", "NoRAG")}
    for k in ids:
        for ri in (0, 1): dist[key[k]][R[ri][k]["faithfulness"]] += 1
    out["faithfulness_counts_both_raters"] = {s: dict(c) for s, c in dist.items()}
    print("\nFaithfulness counts (both raters pooled):", out["faithfulness_counts_both_raters"])

    os.makedirs(a.out_dir, exist_ok=True)
    json.dump(out, open(os.path.join(a.out_dir, "human_eval_summary.json"), "w"), indent=2)
    with open(os.path.join(a.out_dir, "ratings_release.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["question_id", "system", "rater", "faithfulness", "answer_correctness_1to5", "kannada_fluency_1to5"])
        for k in ids:
            for ri in (0, 1):
                r = R[ri][k]; w.writerow([k[0], key[k], f"R{ri+1}", r["faithfulness"], int(r["answer_correctness_1to5"]), int(r["kannada_fluency_1to5"])])
    dis = [k for k in ids if R[0][k]["faithfulness"] != R[1][k]["faithfulness"]]
    json.dump([{"question_id": k[0], "system_id": k[1], "r1": R[0][k]["faithfulness"], "r2": R[1][k]["faithfulness"]} for k in dis],
              open(os.path.join(a.out_dir, "disagreements.json"), "w"), indent=2)
    print(f"\n{len(dis)} faithfulness disagreements listed in disagreements.json (report how they were handled; "
          f"this scorer averages both raters and does not adjudicate).")
    print(f"Wrote summary + release CSV -> {a.out_dir}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--rater1", required=True); p.add_argument("--rater2", required=True)
    p.add_argument("--key", required=True); p.add_argument("--out_dir", default="human_study/results")
    run(p.parse_args())
