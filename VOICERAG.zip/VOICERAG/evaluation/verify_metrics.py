"""
evaluation/verify_metrics.py

Re-scores the saved predictions in a results file with the metric code in
compare_eval_v2.py and reports the maximum absolute deviation from the
values stored in the file. Use it to show that the reported tables follow
from the saved predictions and the released implementation.

  python evaluation/verify_metrics.py --results results_FINAL.json          # ROUGE, METEOR, BLEU
  python evaluation/verify_metrics.py --results results_FINAL.json --bert   # also BERT-P/R/F1 (needs the local KN-BERT model)

Run from the repository root. Exit code 1 if any deviation exceeds --tol.
"""
import os, sys, json, argparse, importlib.util

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def load_eval():
    path = os.path.join(ROOT, "evaluation", "compare_eval_v2.py")
    spec = importlib.util.spec_from_file_location("compare_eval_v2", path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--bert", action="store_true")
    ap.add_argument("--tol", type=float, default=1e-4)
    a = ap.parse_args()
    ev = load_eval()
    data = json.load(open(a.results, encoding="utf-8"))
    keys = ["rouge1", "rouge2", "rougeL", "meteor", "bleu"] + (["bert_p", "bert_r", "bert_f1"] if a.bert else [])
    dev = {k: 0.0 for k in keys}; n = 0
    for label, rows in {**data.get("combos", {}), **data.get("no_rag", {})}.items():
        for r in rows:
            if r.get("skipped") or not r.get("answer"):
                continue
            m = ev.all_metrics(r["answer"], r["reference"])
            for k in keys:
                dev[k] = max(dev[k], abs(m[k] - r[k]))
            n += 1
    print(f"Re-scored {n} answered rows from {os.path.basename(a.results)}")
    for k in keys:
        print(f"  max |recomputed - stored| {k:<8} = {dev[k]:.6f}")
    ok = all(v <= a.tol for v in dev.values())
    print("OK: stored metrics are reproduced by the released implementation." if ok else "MISMATCH: see deviations above.")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
