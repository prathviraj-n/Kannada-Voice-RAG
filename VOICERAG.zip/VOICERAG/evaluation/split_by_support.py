"""
evaluation/split_by_support.py

Splits a results JSON's per-question rows into fully-supported /
partially-supported / unsupported / unaudited buckets by source-text
verification status, and reports the coverage-honest aggregate (same
zero-fill-skipped logic as compare_eval_v2.py's _agg()) separately for
each bucket. This answers Reviewer 3's point directly: does the central
RAG-vs-No-RAG / KN-BERT-vs-E5 effect hold on the subset of questions
whose reference answers are actually recoverable from the retrieval
corpus, not just on the full, mixed 76-question benchmark?

HONESTY NOTE — READ BEFORE USING THIS FOR THE MANUSCRIPT:
Only the original 25 questions (kannada_ground_truth_25_BACKFILLED.json)
were ever individually audited against the source textbook, producing
verification_status in {"verified","partial","unverified"} for q1..q25.
The 51 questions added in the expansion batch (q26..q76) have NO
verification_status field at all — they were template-generated and
merged in without the same manual audit. This script labels those
"unaudited", not "verified" — it does NOT assume they're fine. If you
report a "fully-supported subset" result in the manuscript, it should
either (a) be restricted to the audited 25 minus their 5 unsupported
items = 12 genuinely verified questions, which is a very small subset to
draw a significance conclusion from, or (b) you audit the remaining 51
the same way before using them in this split. This script will tell you
exactly how many questions are in each bucket so you can decide; it will
not quietly treat "unaudited" as "supported".

USAGE:
  python evaluation/split_by_support.py \
      --results results_pipelineB_HONEST_final_v2.json \
      --gt_backfilled evaluation/kannada_ground_truth_25_BACKFILLED.json \
      --gt_full evaluation/kannada_ground_truth_76.json \
      --out results_by_support.json
"""
import json, argparse
from typing import List, Dict

MK = ["rouge1", "rouge2", "rougeL", "meteor", "bleu", "bert_p", "bert_r", "bert_f1", "ref_token_coverage"]


def _avg(lst):
    return round(sum(lst) / len(lst), 4) if lst else 0.0


def _agg(rows: List[Dict]) -> Dict:
    """Same full-denominator, zero-fill-skipped logic as compare_eval_v2.py's _agg()."""
    total = len(rows)
    if total == 0:
        return {**{k: 0.0 for k in MK}, "answered": 0, "total": 0, "coverage": 0.0}
    answered = [r for r in rows if not r.get("skipped", False)]
    res = {k: _avg([r.get(k, 0.0) for r in rows]) for k in MK}
    res["answered"] = len(answered)
    res["total"] = total
    res["coverage"] = round(len(answered) / total, 4)
    return res


def build_status_map(backfilled_path: str, full_gt_path: str) -> Dict[str, str]:
    with open(backfilled_path, encoding="utf-8") as f:
        backfilled = json.load(f)
    with open(full_gt_path, encoding="utf-8") as f:
        full_gt = json.load(f)

    status = {q["id"]: q.get("verification_status", "unaudited") for q in backfilled}
    for q in full_gt:
        status.setdefault(q["id"], "unaudited")  # anything not in backfilled = never audited
    return status


def run(results_path: str, backfilled_path: str, full_gt_path: str, out_path: str):
    with open(results_path, encoding="utf-8") as f:
        results = json.load(f)
    status_map = build_status_map(backfilled_path, full_gt_path)

    counts = {}
    for s in status_map.values():
        counts[s] = counts.get(s, 0) + 1
    print("Question counts by verification status (from source-text audit):")
    for s, n in sorted(counts.items()):
        print(f"  {s:<14} {n}")
    print(f"  {'TOTAL':<14} {len(status_map)}\n")
    if counts.get("unaudited", 0) > 0:
        print(f"WARNING: {counts['unaudited']} questions have never been individually "
              f"checked against the source text. They are reported as their own bucket "
              f"below, NOT folded into 'verified'. See this script's docstring.\n")

    all_sections = {**results.get("combos", {}), **results.get("no_rag", {})}
    out = {"status_counts": counts, "by_config": {}}

    buckets = ["verified", "partial", "unverified", "unaudited"]
    header = f"{'Configuration':<45} | " + " | ".join(f"{b[:9]:>11}" for b in buckets)
    print(header)
    print("-" * len(header))

    for label, rows in all_sections.items():
        by_bucket = {b: [] for b in buckets}
        for r in rows:
            s = status_map.get(r["id"], "unaudited")
            by_bucket.setdefault(s, []).append(r)

        out["by_config"][label] = {}
        line = f"{label:<45} | "
        cells = []
        for b in buckets:
            agg = _agg(by_bucket.get(b, []))
            out["by_config"][label][b] = agg
            cells.append(f"{agg.get('bert_f1', 0.0):>7.4f}(n={agg['total']:<2})")
        print(line + " | ".join(f"{c:>11}" for c in cells))

    # Paired bootstrap: each RAG configuration minus the No-RAG baseline that
    # uses the SAME generator, within each support bucket, over questions both
    # systems answered. Small buckets give wide intervals — report them as such.
    import numpy as np
    rng = np.random.default_rng(11)
    print("\nPaired BERT-F1 difference, RAG minus same-LLM No-RAG (95% bootstrap CI):")
    out["paired_vs_norag"] = {}
    for label in results.get("combos", {}):
        llm = label.split("|")[-1].strip()
        base = {r["id"]: r for r in results.get("no_rag", {}).get(f"NoRAG|{llm}", [])}
        rag = {r["id"]: r for r in results["combos"][label]}
        for b in ("verified", "partial", "unverified", "unaudited", "verified+partial"):
            want = {"verified+partial": ("verified", "partial")}.get(b, (b,))
            ids = [q for q in rag if status_map.get(q, "unaudited") in want and q in base
                   and not rag[q].get("skipped") and not base[q].get("skipped")]
            if len(ids) < 5:
                continue
            d = np.array([rag[q]["bert_f1"] - base[q]["bert_f1"] for q in ids])
            bm = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(10000)]
            lo, hi = np.percentile(bm, [2.5, 97.5])
            out["paired_vs_norag"].setdefault(label, {})[b] = {
                "n": len(ids), "mean_diff": round(float(d.mean()), 4),
                "ci95": [round(float(lo), 4), round(float(hi), 4)]}
            print(f"  {label:<44} {b:<17} n={len(ids):<3} diff={d.mean():+.4f}  [{lo:+.4f}, {hi:+.4f}]")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\nWrote -> {out_path}")
    print("\nFor the manuscript: report the 'verified' column (and ideally 'verified'+'partial') "
          "as the fully/partially-supported-subset result Reviewer 3 asked for, state the n for "
          "that subset explicitly, and do not claim the 'unaudited' bucket is supported — say "
          "plainly that those 51 questions were not individually checked against the source text.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--results", required=True)
    p.add_argument("--gt_backfilled", required=True)
    p.add_argument("--gt_full", required=True)
    p.add_argument("--out", default="results_by_support.json")
    args = p.parse_args()
    run(args.results, args.gt_backfilled, args.gt_full, args.out)
