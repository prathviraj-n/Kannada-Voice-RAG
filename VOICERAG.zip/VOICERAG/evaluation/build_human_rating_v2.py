"""
evaluation/build_human_rating_v2.py

Builds the blinded human faithfulness-rating workbooks for ONE run of the
system (the run in --results), comparing a RAG configuration against the
same-generator No-RAG baseline.

What raters see, per question: the question, the reference answer, the
passages the RAG system retrieved (with page numbers), and two anonymous
answers A/B (random order per question). They never see which is RAG.
Ratings: faithfulness (4 categories), answer correctness (1-5), Kannada
fluency (1-5), and free-text notes.

Evidence: results files store only retrieved PAGE NUMBERS, so the passages
are re-retrieved with the same index/embedder/top_k (retrieval involves no
LLM and is deterministic). The script checks the re-retrieved pages equal
the pages stored in the results file and reports any mismatch.

USAGE (run from the repo root on the machine that has the indexes):
  python evaluation/build_human_rating_v2.py \
      --results results_FINAL.json \
      --rag_label "kannada-bert | hybrid | openai/gpt-oss-120b" \
      --norag_label "NoRAG|openai/gpt-oss-120b" \
      --n_per_tier 10 --seed 42 --out_dir human_study

Writes in --out_dir:
  rater1.xlsx, rater2.xlsx      identical content, one per rater (send separately)
  ANSWER_KEY_DO_NOT_SHARE.json  A/B -> RAG/NoRAG mapping
  protocol.json                 seed, labels, counts, results-file hash (for the paper)
Do NOT let the raters see each other's file or the key.
"""
import os, sys, json, random, hashlib, argparse, datetime

FAITH = ["supported", "partially_supported", "contradicted", "unsupported"]
MAX_PASSAGE_CHARS = 700

INSTR = [
    ("Kannada educational QA - human rating instructions", True, 16),
    ("", False, 11),
    ("For each question you see the question, a reference answer, and the text passages retrieved "
     "from the textbook (with page numbers). Two anonymous answers, A and B, follow. You are not told "
     "which system wrote which. Rate each answer independently. Do not discuss ratings with the other rater.", False, 12),
    ("", False, 11),
    ("faithfulness (dropdown) - judge the answer's claims against the REFERENCE ANSWER and the "
     "RETRIEVED PASSAGES shown:", True, 12),
    ("  supported - every substantive claim is backed by the reference answer or the passages.", False, 11),
    ("  partially_supported - some claims are backed, but others are missing, extra, or cannot be checked.", False, 11),
    ("  contradicted - at least one claim conflicts with the reference answer or the passages.", False, 11),
    ("  unsupported - the answer is unrelated, empty, or nothing in it can be checked.", False, 11),
    ("If an answer is correct from your own knowledge but is not backed by the reference or passages, "
     "do not mark it supported; add a note.", False, 11),
    ("", False, 11),
    ("answer_correctness_1to5 / kannada_fluency_1to5 (dropdown)", True, 12),
    ("  1 poor, 2 below average, 3 adequate, 4 good, 5 excellent.", False, 11),
    ("  Correctness: does the answer correctly address what was asked?", False, 11),
    ("  Fluency: is the Kannada natural and grammatical, independent of correctness?", False, 11),
    ("", False, 11),
    ("Rate every row. Use annotator_notes for anything unclear. Save the file under the same name and return it.", False, 12),
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def fetch_evidence(qrows, rag_label, top_k=5):
    """Re-retrieve passages for the sampled questions with the RAG config."""
    sys.path.insert(0, os.getcwd())
    from src.compare.compare_orchestrator import (ComboConfig, _load_index_for_combo,
                                                  _embed_query, _hybrid_search, _dense_search)
    emb, mode, llm = [x.strip() for x in rag_label.split("|")]
    cfg = ComboConfig(emb, mode, llm)
    out, mismatches = {}, 0
    for qid, r in qrows.items():
        index, bm25, df = _load_index_for_combo(r["source_pdf"], cfg)
        qe = _embed_query(r["question"], cfg)
        chunks = (_hybrid_search(index, bm25, df, qe, r["question"], top_k)
                  if mode == "hybrid" and bm25 is not None else _dense_search(index, df, qe, top_k))
        out[qid] = [{"page": c.get("page", 0), "text": c["text"]} for c in chunks]
        if [c["page"] for c in out[qid]] != list(r.get("retrieved_pages", [])):
            mismatches += 1
    print(f"Evidence re-retrieved for {len(out)} questions; page-list mismatches vs results file: {mismatches}")
    if mismatches:
        print("  WARNING: re-retrieval differs from the run being rated. Do not use this evidence "
              "unless the indexes are the ones used for the run.")
    return out, mismatches


def fmt_evidence(passages):
    if not passages:
        return "(no passages available)"
    parts = []
    for i, p in enumerate(passages, 1):
        t = " ".join(p["text"].split())
        if len(t) > MAX_PASSAGE_CHARS:
            t = t[:MAX_PASSAGE_CHARS] + " ..."
        parts.append(f"[{i}] (page {p['page']}) {t}")
    return "\n\n".join(parts)


def write_workbook(path, rows, cols):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter as L
    wb = Workbook(); wi = wb.active; wi.title = "Instructions"
    for i, (txt, bold, size) in enumerate(INSTR, 1):
        c = wi.cell(row=i, column=1, value=txt)
        c.font = Font(name="Arial", bold=bold, size=size); c.alignment = Alignment(wrap_text=True, vertical="top")
    wi.column_dimensions["A"].width = 110
    ws = wb.create_sheet("Ratings")
    for j, n in enumerate(cols, 1):
        c = ws.cell(row=1, column=j, value=n)
        c.font = Font(name="Arial", bold=True); c.fill = PatternFill("solid", fgColor="D9E1F2")
    edit = {"faithfulness", "answer_correctness_1to5", "kannada_fluency_1to5", "annotator_notes"}
    fill = PatternFill("solid", fgColor="FFF2CC")
    for i, r in enumerate(rows, 2):
        for j, n in enumerate(cols, 1):
            c = ws.cell(row=i, column=j, value=r.get(n, ""))
            c.font = Font(name="Arial", size=11); c.alignment = Alignment(wrap_text=True, vertical="top")
            if n in edit: c.fill = fill
    widths = {"question_id": 10, "difficulty": 10, "question": 40, "reference_answer": 45,
              "retrieved_evidence": 70, "system_id": 9, "system_answer": 45, "faithfulness": 20,
              "answer_correctness_1to5": 16, "kannada_fluency_1to5": 14, "annotator_notes": 30}
    for j, n in enumerate(cols, 1): ws.column_dimensions[L(j)].width = widths.get(n, 14)
    last = len(rows) + 1
    dv = DataValidation(type="list", formula1='"' + ",".join(FAITH) + '"', allow_blank=True)
    ws.add_data_validation(dv); c = L(cols.index("faithfulness") + 1); dv.add(f"{c}2:{c}{last}")
    for f in ("answer_correctness_1to5", "kannada_fluency_1to5"):
        d = DataValidation(type="whole", operator="between", formula1=1, formula2=5, allow_blank=True)
        d.error = "Whole number 1-5"; ws.add_data_validation(d); c = L(cols.index(f) + 1); d.add(f"{c}2:{c}{last}")
    ws.freeze_panes = "A2"
    wb.save(path)


def run(a):
    rng = random.Random(a.seed)
    data = json.load(open(a.results, encoding="utf-8"))
    secs = {**data.get("combos", {}), **data.get("no_rag", {})}
    rag = {r["id"]: r for r in secs[a.rag_label] if not r.get("skipped") and r.get("answer")}
    nor = {r["id"]: r for r in secs[a.norag_label] if not r.get("skipped") and r.get("answer")}
    common = sorted(set(rag) & set(nor))
    sampled = []
    for tier in ("easy", "medium", "hard"):
        ids = [q for q in common if rag[q].get("difficulty") == tier]
        k = min(a.n_per_tier, len(ids))
        sampled += rng.sample(ids, k)
        print(f"  {tier}: sampled {k} of {len(ids)} eligible")
    rng.shuffle(sampled)

    if a.no_evidence:
        ev, mism = {q: [] for q in sampled}, None
        print("WARNING: --no_evidence set; raters will NOT see retrieved passages.")
    else:
        ev, mism = fetch_evidence({q: rag[q] for q in sampled}, a.rag_label)

    rows, key = [], []
    for q in sampled:
        entries = [("RAG", rag[q]["answer"]), ("NoRAG", nor[q]["answer"])]
        rng.shuffle(entries)
        for sid, (true_sys, ans) in zip(("A", "B"), entries):
            rows.append({"question_id": q, "difficulty": rag[q]["difficulty"], "question": rag[q]["question"],
                         "reference_answer": rag[q]["reference"], "retrieved_evidence": fmt_evidence(ev[q]),
                         "system_id": sid, "system_answer": ans, "faithfulness": "",
                         "answer_correctness_1to5": "", "kannada_fluency_1to5": "", "annotator_notes": ""})
            key.append({"question_id": q, "system_id": sid, "true_system": true_sys})
    cols = ["question_id", "difficulty", "question", "reference_answer", "retrieved_evidence", "system_id",
            "system_answer", "faithfulness", "answer_correctness_1to5", "kannada_fluency_1to5", "annotator_notes"]
    os.makedirs(a.out_dir, exist_ok=True)
    for name in ("rater1.xlsx", "rater2.xlsx"):
        write_workbook(os.path.join(a.out_dir, name), rows, cols)
    json.dump(key, open(os.path.join(a.out_dir, "ANSWER_KEY_DO_NOT_SHARE.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    json.dump({"created": datetime.datetime.now().isoformat(timespec="seconds"), "seed": a.seed,
               "results_file": os.path.basename(a.results), "results_sha256": sha256(a.results),
               "rag_label": a.rag_label, "norag_label": a.norag_label, "n_per_tier": a.n_per_tier,
               "n_questions": len(sampled), "n_rows_per_rater": len(rows),
               "evidence_shown": not a.no_evidence, "evidence_page_mismatches": mism,
               "question_ids": sampled}, open(os.path.join(a.out_dir, "protocol.json"), "w"), indent=2)
    print(f"\nWrote {len(rows)} rows ({len(sampled)} questions x 2 answers) -> {a.out_dir}/rater1.xlsx, rater2.xlsx")
    print("Send each rater ONLY their own file. Keep ANSWER_KEY_DO_NOT_SHARE.json private.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--results", required=True); p.add_argument("--rag_label", required=True)
    p.add_argument("--norag_label", required=True); p.add_argument("--n_per_tier", type=int, default=10)
    p.add_argument("--seed", type=int, default=42); p.add_argument("--out_dir", default="human_study")
    p.add_argument("--no_evidence", action="store_true", help="skip passage retrieval (not recommended)")
    run(p.parse_args())
