"""
evaluation/retrieval_eval.py

Real passage-level retrieval evaluation against annotated gold evidence,
replacing the lexical-overlap "recall_at_k" proxy Reviewer 3 correctly
flagged (token overlap between retrieved text and the reference answer is
not retrieval recall against annotated relevant evidence).

This uses the ONLY gold-evidence annotation that actually exists in the
ground-truth files: gold_pages (a list of source-PDF page numbers judged
to contain the answer). gold_chunk_ids is present in the schema but is
empty ({}) for every question in both kannada_ground_truth_76.json and
kannada_ground_truth_25_BACKFILLED.json — it was never populated, so this
script works at PAGE granularity, not chunk granularity. Say so explicitly
wherever these numbers are reported; do not call this "chunk-level recall".

Only 51 of the 76 ground-truth questions currently have gold_pages
annotated (the rest have gold_pages: []) — this script reports results
over exactly that covered subset and prints how many questions that is,
so the denominator is never silently smaller than it looks.

Requires a results JSON produced by the PATCHED compare_eval_v2.py /
compare_orchestrator.py (the ones in this repo), which now save
"retrieved_pages" per row — a pre-patch results file won't have this
field and this script will report 0 coverage for every config.

Metrics reported per configuration, over the gold_pages-covered subset:
  Hit@k   — fraction of questions where >=1 of the top-k retrieved chunks
            came from a gold page (k = number of chunks actually retrieved,
            typically 5; this is NOT varied/swept here)
  MRR     — mean reciprocal rank of the first retrieved chunk whose page
            is a gold page (0 if none of the top-k are)
  nDCG@k  — binary-relevance nDCG@k (relevance=1 if chunk's page is a gold
            page, else 0), log2 discounted by rank

USAGE:
  python evaluation/retrieval_eval.py \
      --results results_pipelineB_HONEST_final_v2.json \
      --gt evaluation/kannada_ground_truth_76.json \
      --out retrieval_only_results.json
"""
import json, math, argparse
from typing import List, Dict


def load_gold_pages(gt_path: str) -> Dict[str, List[int]]:
    with open(gt_path, encoding="utf-8") as f:
        gt = json.load(f)
    return {q["id"]: q.get("gold_pages", []) for q in gt if q.get("gold_pages")}


def hit_at_k(retrieved_pages: List[int], gold_pages: List[int]) -> int:
    gold = set(gold_pages)
    return 1 if any(p in gold for p in retrieved_pages) else 0


def reciprocal_rank(retrieved_pages: List[int], gold_pages: List[int]) -> float:
    gold = set(gold_pages)
    for rank, p in enumerate(retrieved_pages, start=1):
        if p in gold:
            return 1.0 / rank
    return 0.0


def ndcg_at_k(retrieved_pages: List[int], gold_pages: List[int]) -> float:
    """
    Binary-relevance nDCG@k at PAGE level. A page counts only at its first
    appearance in the ranking: several retrieved chunks from the same gold
    page are one piece of evidence, not several, so repeats earn no gain.
    (Without this, repeats can push DCG above the ideal DCG and nDCG above 1.)
    """
    gold = set(gold_pages)
    seen, dcg = set(), 0.0
    for i, p in enumerate(retrieved_pages):
        if p in gold and p not in seen:
            dcg += 1.0 / math.log2(i + 2)
        seen.add(p)
    n_rel = min(len(gold), len(retrieved_pages))
    idcg = sum(1.0 / math.log2(i + 2) for i in range(n_rel))
    return dcg / idcg if idcg > 0 else 0.0


def _boot_ci(vals, n_boot=10000, seed=7):
    import numpy as np
    rng = np.random.default_rng(seed)
    v = np.asarray(vals, dtype=float)
    means = [v[rng.integers(0, len(v), len(v))].mean() for _ in range(n_boot)]
    return [round(float(x), 4) for x in np.percentile(means, [2.5, 97.5])]


def _paired_boot(a, b, n_boot=10000, seed=7):
    import numpy as np
    rng = np.random.default_rng(seed)
    d = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    means = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(n_boot)]
    lo, hi = np.percentile(means, [2.5, 97.5])
    return round(float(d.mean()), 4), [round(float(lo), 4), round(float(hi), 4)]


def run(results_path: str, gt_path: str, out_path: str):
    with open(results_path, encoding="utf-8") as f:
        results = json.load(f)
    gold_by_id = load_gold_pages(gt_path)
    with open(gt_path, encoding="utf-8") as f:
        n_total_gt = len(json.load(f))

    print(f"Gold-page annotations available for {len(gold_by_id)}/{n_total_gt} questions. "
          f"Retrieval metrics are computed ONLY over this covered subset.\n")

    # Retrieval does not depend on which LLM answers, so pool all labels that
    # share the same "embedder | retrieval-mode" prefix. A question's retrieved
    # pages are taken from any LLM's row where they were recorded (rows for
    # skipped generations carry no pages, which would otherwise understate
    # retrieval quality for reasons unrelated to retrieval).
    retr = {}
    for label, rows in results.get("combos", {}).items():
        embed, mode, _llm = [x.strip() for x in label.split("|")]
        key = f"{embed} | {mode}"
        pages = retr.setdefault(key, {})
        for r in rows:
            if r.get("retrieved_pages") and r["id"] not in pages:
                pages[r["id"]] = r["retrieved_pages"]

    per_q = {}
    print(f"{'Retrieval configuration':<26} | {'n':>3} | {'Hit@k [95% CI]':>24} | {'MRR [95% CI]':>24} | {'nDCG@k [95% CI]':>24}")
    print("-" * 112)
    out = {}
    for key, pages in retr.items():
        ids = [q for q in gold_by_id if q in pages]
        hits = [hit_at_k(pages[q], gold_by_id[q]) for q in ids]
        rrs = [reciprocal_rank(pages[q], gold_by_id[q]) for q in ids]
        nd = [ndcg_at_k(pages[q], gold_by_id[q]) for q in ids]
        per_q[key] = {"ids": ids, "hit": hits, "mrr": rrs, "ndcg": nd}
        out[key] = {"n_covered": len(ids), "n_missing": len(gold_by_id) - len(ids)}
        cells = []
        for name, v in (("hit_at_k", hits), ("mrr", rrs), ("ndcg_at_k", nd)):
            m = round(sum(v) / len(v), 4); ci = _boot_ci(v)
            out[key][name] = {"mean": m, "ci95": ci}
            cells.append(f"{m:.4f} [{ci[0]:.3f},{ci[1]:.3f}]")
        print(f"{key:<26} | {len(ids):>3} | {cells[0]:>24} | {cells[1]:>24} | {cells[2]:>24}")

    print("\nPaired differences, KN-BERT minus E5 (same questions, 10,000 bootstrap resamples):")
    paired = {}
    for mode in ("hybrid", "dense"):
        a, b = per_q.get(f"kannada-bert | {mode}"), per_q.get(f"e5 | {mode}")
        if not a or not b:
            continue
        common = [q for q in a["ids"] if q in set(b["ids"])]
        ia = {q: k for k, q in enumerate(a["ids"])}; ib = {q: k for k, q in enumerate(b["ids"])}
        for name in ("hit", "mrr", "ndcg"):
            d, ci = _paired_boot([a[name][ia[q]] for q in common], [b[name][ib[q]] for q in common])
            paired[f"{mode}_{name}"] = {"n": len(common), "mean_diff": d, "ci95": ci}
            print(f"  {mode:<6} {name:<5} n={len(common)}  diff={d:+.4f}  95% CI [{ci[0]:+.4f}, {ci[1]:+.4f}]")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"n_gt_total": n_total_gt, "n_gold_page_covered": len(gold_by_id),
                   "by_retrieval_config": out, "paired_kn_minus_e5": paired}, f, ensure_ascii=False, indent=2)
    print(f"\nWrote -> {out_path}")
    print("\nThese are PAGE-level metrics (gold_chunk_ids is empty for every question). No-RAG "
          "has no retrieval step and is not listed. Keep this table separate from the "
          "BERTScore/ROUGE generation-quality tables.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--results", required=True)
    p.add_argument("--gt", required=True)
    p.add_argument("--out", default="retrieval_only_results.json")
    args = p.parse_args()
    run(args.results, args.gt, args.out)
