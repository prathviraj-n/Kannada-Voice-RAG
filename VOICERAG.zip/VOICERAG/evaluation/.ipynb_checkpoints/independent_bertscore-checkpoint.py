"""
evaluation/independent_bertscore.py

Controlled evaluator-sensitivity analysis for the BERT-F1 answer-reference
similarity score.

WHY: the primary BERT-F1 is computed with l3cube-pune/kannada-sentence-bert-nli,
the same model used for KN-BERT retrieval, so an evaluator-retriever coupling
is possible. Re-scoring with a model outside the retrieval configurations
tests whether conclusions depend on the evaluator.

HOW (controlled): this script reimplements the primary scorer exactly --
same text normalisation (NFC, Kannada-script characters only), same
last-layer token embeddings, L2-normalised, greedy max-similarity matching,
P/R/F1, no IDF, no baseline rescaling -- and runs it with two models:

  1. CONTROL      the KN-BERT model, through THIS code path. Its scores must
                  reproduce the primary bert_f1 in the results file; the
                  script reports the maximum absolute deviation. If it does
                  not match, the two pipelines differ and the comparison
                  below is NOT controlled.
  2. INDEPENDENT  a model outside the study's retrieval configurations
                  (default bert-base-multilingual-cased; avoid
                  intfloat/multilingual-e5-* since that is a retrieval
                  configuration). Only the model differs from the control,
                  so any change in a conclusion is attributable to the
                  evaluator model, not preprocessing or implementation.

Fields written to every row:
  bert_f1_control      KN-BERT through this script's path (reproduces bert_f1)
  bert_f1_independent  the independent model (use with significance_test.py)
Skipped rows get 0.0, matching the full-denominator rule used elsewhere;
significance_test.py excludes skipped questions from paired tests anyway.

USAGE (the box needs internet for the independent model's first download):
  python evaluation/independent_bertscore.py \
      --results results_FINAL.json \
      --model bert-base-multilingual-cased \
      --out results_FINAL_with_independent.json

Then test it with the same pre-specified family as the primary analysis:
  python evaluation/significance_test.py \
      --results results_FINAL_with_independent.json \
      --metric bert_f1_independent --family
"""
import os, re, json, argparse, unicodedata


def normalize_kannada(text: str) -> str:
    """Identical to compare_eval_v2.normalize_kannada (kept in sync deliberately)."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", text)
    text = re.sub(r'[^ಀ-೿\s।॥,.!?]', ' ', text)
    return ' '.join(text.split()).strip()


def find_control_model(explicit: str) -> str:
    cands = [explicit] if explicit else []
    cands += ["models/l3cube-pune/kannada-sentence-bert-nli",
              "backend/models/l3cube-pune/kannada-sentence-bert-nli"]
    for c in cands:
        if c and os.path.isdir(c):
            return c
    raise SystemExit("KN-BERT control model not found. Pass --control_path <dir>.")


class Scorer:
    def __init__(self, name_or_path: str, local_only: bool):
        import torch
        from transformers import AutoTokenizer, AutoModel
        self.torch = torch
        self.name = name_or_path
        self.dev = "cuda" if torch.cuda.is_available() else "cpu"
        self.tok = AutoTokenizer.from_pretrained(name_or_path, local_files_only=local_only)
        self.mod = AutoModel.from_pretrained(name_or_path, local_files_only=local_only).to(self.dev).eval()
        self.cache = {}

    def emb(self, text: str):
        if text in self.cache:
            return self.cache[text]
        enc = self.tok(text, return_tensors="pt", truncation=True, max_length=512, padding=False)
        enc = {k: v.to(self.dev) for k, v in enc.items()}
        with self.torch.no_grad():
            h = self.mod(**enc).last_hidden_state.squeeze(0)[1:-1]   # drop [CLS]/[SEP]
        h = h / h.norm(dim=-1, keepdim=True).clamp(min=1e-9)
        self.cache[text] = h
        return h

    def f1(self, pred: str, ref: str) -> float:
        ep, er = self.emb(normalize_kannada(pred)), self.emb(normalize_kannada(ref))
        if ep.shape[0] == 0 or er.shape[0] == 0:
            return 0.0
        sim = self.torch.mm(ep, er.T)
        P = sim.max(dim=1).values.mean().item()
        R = sim.max(dim=0).values.mean().item()
        return round(2 * P * R / (P + R), 4) if (P + R) > 1e-9 else 0.0


def run(results_path, model_name, control_path, out_path):
    with open(results_path, encoding="utf-8") as f:
        data = json.load(f)
    sections = {**data.get("combos", {}), **data.get("no_rag", {})}

    control_dir = find_control_model(control_path)
    print(f"Control model     : {control_dir}  (local)")
    print(f"Independent model : {model_name}  (downloaded from the Hub if not cached)\n")
    control = Scorer(control_dir, local_only=True)
    indep = Scorer(model_name, local_only=False)

    max_dev = 0.0
    for label, rows in sections.items():
        n_scored = 0
        for r in rows:
            if r.get("skipped") or not r.get("answer"):
                r["bert_f1_control"] = 0.0
                r["bert_f1_independent"] = 0.0
                continue
            r["bert_f1_control"] = control.f1(r["answer"], r["reference"])
            r["bert_f1_independent"] = indep.f1(r["answer"], r["reference"])
            max_dev = max(max_dev, abs(r["bert_f1_control"] - r.get("bert_f1", 0.0)))
            n_scored += 1
        print(f"scored {label:<50} {n_scored}/{len(rows)}")

    data.setdefault("meta", {})["independent_evaluator"] = {
        "independent_model": model_name, "control_model": control_dir,
        "implementation": "same greedy-matching last-layer scorer and normalisation as primary",
        "max_abs_dev_control_vs_primary": round(max_dev, 6)}
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"\nWrote -> {out_path}")

    print(f"\nCONTROL CHECK: max |bert_f1_control - bert_f1 (primary)| = {max_dev:.6f}")
    if max_dev > 1e-3:
        print("  WARNING: the control does not reproduce the primary scores, so this script's "
              "path differs from the one that produced them. The comparison is NOT controlled "
              "-- do not report it as such until this is resolved.")
    else:
        print("  OK: control reproduces the primary scores; only the evaluator model differs.")

    def mean_full(rows, k): return sum(r.get(k, 0.0) for r in rows) / len(rows)
    print(f"\n{'Configuration':<50} {'primary':>8} {'control':>8} {'indep.':>8} {'indep-prim':>11}")
    for label, rows in sections.items():
        p, c, i = (mean_full(rows, k) for k in ("bert_f1", "bert_f1_control", "bert_f1_independent"))
        print(f"{label:<50} {p:>8.4f} {c:>8.4f} {i:>8.4f} {i - p:>+11.4f}")
    print("\nMeans are full-denominator (skipped questions count as 0). Report paired CIs and "
          "adjusted p-values from significance_test.py, not these means alone.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--results", required=True)
    p.add_argument("--model", default="bert-base-multilingual-cased")
    p.add_argument("--control_path", default="")
    p.add_argument("--out", required=True)
    a = p.parse_args()
    run(a.results, a.model, a.control_path, a.out)
